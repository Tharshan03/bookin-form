import React from "react";
import DatePicker from "react-datepicker";
import Select from "react-select";
import { destinations } from "../data/destinations";

export default function Step1_TripBasic({
  t,
  tripType, setTripType,
  departure, setDeparture,
  arrival, setArrival,
  selectedHotel, setSelectedHotel,
  departureDate, setDepartureDate,
  returnDate, setReturnDate,
  price,
  hotelOptions,
  departureAddress, setDepartureAddress,
  arrivalAddress, setArrivalAddress,
  /** 👇 ajoutés */
  passengers, setPassengers,
  /** 👆 */
  nextStep,
  embedded = false,
}) {
  const departureOptions = [
    { label: "France", options: destinations.filter(d => d.country === "France" && d.value !== arrival) },
    { label: "Belgique", options: destinations.filter(d => d.country === "Belgique" && d.value !== arrival) },
    { label: "Pays-Bas", options: destinations.filter(d => d.country === "Pays-Bas" && d.value !== arrival) },
  ];
  const arrivalOptions = [
    { label: "France", options: destinations.filter(d => d.country === "France" && d.value !== departure) },
    { label: "Belgique", options: destinations.filter(d => d.country === "Belgique" && d.value !== departure) },
    { label: "Pays-Bas", options: destinations.filter(d => d.country === "Pays-Bas" && d.value !== departure) },
  ];

  return (
    <div className="w-full">
      <form
        className={`bg-white rounded-xl shadow-md p-4 md:p-5 w-full ${embedded ? "max-w-none" : "max-w-sm"} mx-auto`}
        onSubmit={(e) => { e.preventDefault(); nextStep(); }}
      >
        <h2 className="text-xl font-bold mb-4 text-center">{t.step1_title}</h2>

        {/* Type de trajet */}
        <div className="flex justify-center gap-2 mb-4">
          <button
            type="button"
            className={`px-3 py-1.5 rounded-lg text-sm font-semibold border transition ${tripType === "one-way" ? "bg-blue-600 text-white shadow" : "bg-gray-100 text-gray-700"}`}
            onClick={() => setTripType("one-way")}
          >
            {t.one_way}
          </button>
          <button
            type="button"
            className={`px-3 py-1.5 rounded-lg text-sm font-semibold border transition ${tripType === "round-trip" ? "bg-blue-600 text-white shadow" : "bg-gray-100 text-gray-700"}`}
            onClick={() => setTripType("round-trip")}
          >
            {t.round_trip}
          </button>
          <button
            type="button"
            className={`px-3 py-1.5 rounded-lg text-sm font-semibold border transition ${tripType === "excursion" ? "bg-blue-600 text-white shadow" : "bg-gray-100 text-gray-700"}`}
            onClick={() => setTripType("excursion")}
          >
            {t.excursion}
          </button>
        </div>

        {/* Dates (alignées côte-à-côte en desktop pour AR) */}
        <div className={`grid grid-cols-1 ${tripType === "round-trip" ? "lg:grid-cols-2 lg:gap-4" : ""}`}>
          {/* Date & heure de départ */}
          <div className="mb-4">
            <label className="block font-semibold mb-1">📅 Date & heure de départ</label>
            <DatePicker
              selected={departureDate}
              onChange={(d) => setDepartureDate(d)}
              showTimeSelect
              timeIntervals={15}
              dateFormat="dd/MM/yyyy HH:mm"
              minDate={new Date()}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          {/* Date de retour (AR seulement) */}
          {tripType === "round-trip" && (
            <div className="mb-4 lg:mb-0">
              <label className="block font-semibold mb-1">📅 Date de retour</label>
              <DatePicker
                selected={returnDate}
                onChange={(d) => setReturnDate(d)}
                showTimeSelect
                timeIntervals={15}
                dateFormat="dd/MM/yyyy HH:mm"
                minDate={departureDate || new Date()}
                className="w-full border rounded px-3 py-2"
              />
            </div>
          )}
        </div>

        {/* Départ */}
        <div className="mb-3">
          <label className="block text-sm font-semibold mb-1">🚩 {t.departure}</label>
          <Select
            options={departureOptions}
            value={destinations.find(opt => opt.value === departure)}
            onChange={(opt) => setDeparture(opt.value)}
            placeholder="Sélectionnez la ville de départ"
            isSearchable
            styles={{ control: base => ({ ...base, minHeight: 38 }) }}
          />
        </div>

        {/* Adresse si départ = Paris */}
        {departure === "paris" && (
          <div className="mb-3 flex items-center gap-2">
            <span>📍</span>
            <input
              type="text"
              className="w-full border rounded px-3 py-2 text-sm"
              value={departureAddress}
              onChange={(e) => setDepartureAddress(e.target.value)}
              placeholder={t.address_placeholder || "Indiquez votre adresse"}
              required
            />
          </div>
        )}

        {/* Arrivée */}
        <div className="mb-3">
          <label className="block text-sm font-semibold mb-1">🏁 {t.arrival}</label>
          <Select
            options={arrivalOptions}
            value={destinations.find(opt => opt.value === arrival)}
            onChange={(opt) => setArrival(opt.value)}
            placeholder="Sélectionnez la ville d'arrivée"
            isSearchable
            styles={{ control: base => ({ ...base, minHeight: 38 }) }}
          />
        </div>

        {/* Adresse si arrivée = Paris */}
        {arrival === "paris" && (
          <div className="mb-3 flex items-center gap-2">
            <span>📍</span>
            <input
              type="text"
              className="w-full border rounded px-3 py-2 text-sm"
              value={arrivalAddress}
              onChange={(e) => setArrivalAddress(e.target.value)}
              placeholder={t.address_placeholder || "Indiquez votre adresse"}
              required
            />
          </div>
        )}

        {/* Hôtel Disney si besoin */}
        {(departure === "disney" || arrival === "disney") && (
          <div className="mb-3">
            <label className="block text-sm font-semibold mb-1">🏨 {t.selectHotel}</label>
            <Select
              options={hotelOptions}
              value={selectedHotel}
              onChange={setSelectedHotel}
              isClearable
              placeholder={t.hotelPlaceholder}
              styles={{ control: base => ({ ...base, minHeight: 38 }) }}
            />
          </div>
        )}

        {/* === Passagers + Prix + Continuer === */}
        <div className="mt-4 space-y-3">
          {/* Sélecteur de passagers */}
          <div>
            <label className="block font-semibold mb-1">🧍 Passager(s)</label>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setPassengers(p => Math.max(1, p - 1))}
                className="h-9 w-9 rounded-lg border bg-white hover:bg-slate-50 grid place-items-center"
                aria-label="Diminuer"
              >
                –
              </button>

              <div className="min-w-[72px] text-center font-semibold text-lg select-none">
                {passengers}
              </div>

              <button
                type="button"
                onClick={() => setPassengers(p => Math.min(16, p + 1))}
                className="h-9 w-9 rounded-lg border bg-white hover:bg-slate-50 grid place-items-center"
                aria-label="Augmenter"
              >
                +
              </button>
            </div>
          </div>

          {/* Prix + bouton */}
          <div className="flex items-center gap-3">
            {/* Prix mis en avant */}
            <div className="flex-1">
              <div className="w-full rounded-xl border border-emerald-200 bg-emerald-50/70 px-4 py-3 shadow-[inset_0_1px_0_0_#fff]">
                <div className="text-sm text-emerald-700/90 font-medium">{t.estimatedPrice || "Prix estimé"}</div>
                <div className="text-2xl font-extrabold text-emerald-700 tracking-tight">
                  {price != null ? `${price} €` : "--"}
                </div>
              </div>
            </div>

            {/* Continuer */}
            <button
              type="submit"
              className="h-12 px-6 rounded-xl bg-blue-600 text-white font-semibold shadow-lg hover:bg-blue-700 active:translate-y-[1px] transition"
            >
              {t.next || "Continuer"}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
