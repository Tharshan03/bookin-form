// src/components/BookingFormApp.jsx
import React, { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import { tarifsVtc } from "../data/tarifsVtc";
import translations from "../translations";
import Step1_TripBasic from "./Step1_TripBasic";
import Step1b_TripOptions from "./Step1b_TripOptions";
import Step2_CustomerInfo from "./Step2_CustomerInfo";
import Step3_Recap from "./Step3_Recap";
import { excursions } from "../data/excursions";
import "react-datepicker/dist/react-datepicker.css";

const BookingFormApp = ({ embedded = false }) => {
  const lang = document.documentElement.lang?.substring(0, 2).toLowerCase() || "fr";
  const t = { ...translations.fr, ...translations[lang] };

  const [step, setStep] = useState(1);
  const [tripType, setTripType] = useState("one-way");
  const [departure, setDeparture] = useState("cdg");
  const [arrival, setArrival] = useState("disney");
  const [selectedExcursion, setSelectedExcursion] = useState("paris_4h");
  const [selectedHotel, setSelectedHotel] = useState(null);
  const [departureDate, setDepartureDate] = useState(new Date());
  const [returnDate, setReturnDate] = useState(null);
  const [passengers, setPassengers] = useState(1);
  const [childSeats, setChildSeats] = useState(0);
  const [luggage, setLuggage] = useState(0);
  const [price, setPrice] = useState(null);
  const [selectedVehicle, setSelectedVehicle] = useState("mercedes");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [flightNumber, setFlightNumber] = useState("");
  const [comment, setComment] = useState("");
  const [sending, setSending] = useState(false);
  const [mailStatus, setMailStatus] = useState("");
  const [captchaToken, setCaptchaToken] = useState("");
  const [departureAddress, setDepartureAddress] = useState("");
  const [arrivalAddress, setArrivalAddress] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);

  const hotelOptions = [
    { value: "bb_bussy", label: "B&B Bussy St Georges" },
    { value: "bb_val_france", label: "Hotel B&B Val de France Disney" },
    { value: "bb_bussy", label: "B&B Bussy St Georges" },
    { value: "bb_val_france", label: "Hotel B&B Val de France Disney" },
    { value: "best_western_bussy", label: "Best western Bussy St Georges" },
    { value: "campanile_bussy", label: "Campanile Bussy St Georges" },
    { value: "campanile_torcy", label: "Campanile Torcy" },
    { value: "chessy_gare", label: "Chessy Gare" },
    { value: "citéa_bussy", label: "Citéa Bussy St Georges" },
    { value: "dali", label: "Hotel Dali" },
    { value: "disney_park", label: "Disneyland paris (Park)" },
    { value: "explorers", label: "Hotel Explorers" },
    { value: "gare_mlv", label: "Gare Marne la Vallée" },
    { value: "grand_magic", label: "Grand Magic Hotel" },
    { value: "hotel_cheyenne", label: "Disney's hotel Cheyenne" },
    { value: "hotel_marvel", label: "Disney's hotel Marvel Newyork" },
    { value: "hotel_newport", label: "Disney's hotel Newport Bay Club" },
    { value: "hotel_santa_fe", label: "Disney's hotel Santa Fe" },
    { value: "hotel_sequoia", label: "Disney's hotel Sequoia Lodge" },
    { value: "ibis_val_europe", label: "Ibis Val d'Europe" },
    { value: "moxy", label: "Hotel Moxy Val d'Europe" },
    { value: "others", label: "Others" },
    { value: "paxton", label: "Paxton Ferrière" },
    { value: "radisson_blu", label: "Radisson Blu" },
    { value: "relais_spa", label: "Relais SPA" },
    { value: "residhome", label: "Resid'home" },
    { value: "séjours_affaires", label: "Séjours Affaires Apparthotel" },
    { value: "serris_gare", label: "Serris Gare" },
    { value: "stay_city", label: "Stay city Marne la Vallée" },
    { value: "val_d_europe", label: "Val d'Europe shopping center" },
    { value: "vallée_village", label: "Vallée Village" },
    { value: "vienna", label: "Vienna House Dream Castle Paris" },
    { value: "village_nature", label: "Village Nature" }
  ];

  const vehicleOptions = [
    { id: "mercedes", name: "Mercedes Classe E", extra: 0 },
    { id: "van_standard", name: "Van Standard", extra: 5 },
    { id: "van_vito", name: "Van Vito Premium", extra: 0 },
  ];

  const filteredVehicles =
    passengers <= 4
      ? vehicleOptions.filter((v) => v.id !== "van_vito")
      : vehicleOptions.filter((v) => v.id !== "mercedes");

  const vehicleImages = {
    mercedes: "/images/mercedes.jpg",
    van_standard: "/images/van_standard.jpg",
    van_vito: "/images/van_vito.jpg",
  };

  // Bloque le scroll de la page quand la modal est ouverte
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = isModalOpen ? "hidden" : prev || "";
    return () => {
      document.body.style.overflow = prev || "";
    };
  }, [isModalOpen]);

  // Fermer la modal avec Echap
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape" && isModalOpen) {
        setIsModalOpen(false);
        setStep(1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isModalOpen]);

  // Calcul prix trajets (hors excursions)
  useEffect(() => {
    if (tripType !== "excursion" && departure && arrival && departure !== arrival) {
      const baseKey = `${departure.toLowerCase()}-${arrival.toLowerCase()}`;
      const fullKey = tripType === "round-trip" ? `${baseKey}-${departure.toLowerCase()}` : baseKey;
      const tarifsData = tarifsVtc[tripType];

      if (tarifsData && tarifsData[fullKey]) {
        const basePrice = tarifsData[fullKey][passengers - 1];
        let selectedExtra = 0;
        if (selectedVehicle === "van_standard" && passengers <= 4) selectedExtra = 5;
        setPrice(basePrice + selectedExtra);
      } else {
        setPrice(null);
      }
    } else if (tripType !== "excursion") {
      setPrice(null);
    }
  }, [departure, arrival, tripType, passengers, selectedVehicle]);

  useEffect(() => {
    if (tripType === "one-way") {
      setReturnDate(null);
    } else if (tripType === "round-trip") {
      if (departureDate) {
        setReturnDate((prev) => {
          // si déjà > départ, on garde, sinon on met départ + 7 jours
          if (prev && prev.getTime() > departureDate.getTime()) return prev;
          const d = new Date(departureDate);
          d.setDate(d.getDate() + 7);
          return d;
        });
      }
    }
  }, [tripType, departureDate]);



  // Calcul prix excursions
  useEffect(() => {
    if (tripType === "excursion" && selectedExcursion) {
      const excursionObj = excursions.find((e) => e.value === selectedExcursion);
      setPrice(getExcursionPrice(excursionObj, passengers));
    }
  }, [tripType, selectedExcursion, passengers]);

  function getExcursionPrice(excursion, passengers) {
    if (!excursion) return null;
    if (passengers <= 4) return excursion.prices["1-4"];
    if (passengers <= 8) return excursion.prices["5-8"];
    if (passengers <= 12) return excursion.prices["9-12"];
    return excursion.prices["13-16"];
  }

      // Remplace TA fonction vide par ceci
      const handleConfirm = async () => {
        if (sending) return;
        setSending(true);
        setMailStatus("");

        const bookingId = Date.now().toString();

        const fmt = (d) =>
          d
            ? d.toLocaleString("fr-FR", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
              })
            : "";

        const departureDateFormatted = fmt(departureDate);
        const returnDateFormatted =
          tripType === "round-trip" && returnDate ? fmt(returnDate) : "";

        // Payload compatible avec ton ancien PHP + tes nouveaux champs
        const payload = {
          id: bookingId,

          // --- clés legacy (probables attentes du PHP) ---
          name: fullName,
          pickupDate: departureDateFormatted,
          returnDate: returnDateFormatted, // "" en aller simple
          vehicle: selectedVehicle,

          // --- tes clés actuelles (on les garde) ---
          tripType,
          departure,
          arrival,
          selectedHotel, // { value, label }
          passengers,
          childSeats,
          luggage,
          selectedVehicle,
          price,
          departureAddress,
          arrivalAddress,
          departureDateISO: departureDate ? departureDate.toISOString() : null,
          returnDateISO: returnDate ? returnDate.toISOString() : null,
          departureDateFormatted,
          returnDateFormatted,
          fullName,
          email,
          phone,
          flightNumber,
          comment,
          lang,
          captchaToken,
          adminConfirmationLink: `https://parisairportdisneyprestigetransfer.fr/booking-taxi/confirm-mail.php?id=${bookingId}&email=${encodeURIComponent(
            email
          )}&name=${encodeURIComponent(fullName)}`,
        };

        const SAVE_URL = "/booking-taxi/save-booking.php";
        const SEND_URL = "/booking-taxi/send-mail.php";

        const postJSON = async (url, data) => {
          const res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data),
          });
          const text = await res.text();
          let json;
          try { json = JSON.parse(text); } catch { json = { raw: text }; }
          return { ok: res.ok, status: res.status, json };
        };

        const postForm = async (url, data) => {
          const fd = new FormData();
          Object.entries(data).forEach(([k, v]) =>
            fd.append(k, typeof v === "object" ? JSON.stringify(v) : v ?? "")
          );
          const res = await fetch(url, { method: "POST", body: fd });
          const text = await res.text();
          let json;
          try { json = JSON.parse(text); } catch { json = { raw: text }; }
          return { ok: res.ok, status: res.status, json };
        };

        try {
          // 1) Sauvegarde
          let save = await postJSON(SAVE_URL, payload);
          if (!save.ok) save = await postForm(SAVE_URL, payload);
          if (!save.ok) throw new Error("Erreur d'enregistrement");

          // 2) Envoi mail
          let send = await postJSON(SEND_URL, payload);
          let ok =
            send.ok && (send.json?.success === true || send.json?.status === "success");
          if (!ok) {
            send = await postForm(SEND_URL, payload);
            ok =
              send.ok &&
              (send.json?.success === true || send.json?.status === "success");
          }

          if (ok) setMailStatus("success");
          else throw new Error(send?.json?.message || "Erreur lors de l'envoi mail");
        } catch (e) {
          console.error("❌ Envoi réservation :", e);
          setMailStatus("error");
        } finally {
          setSending(false);
        }
      };



  return (
    <>
      {/* Étape 1 affichée dans la page (Hero) */}
      <div className={embedded ? "h-full" : "max-w-2xl mx-auto p-4"}>
        {step === 1 && (
          <Step1_TripBasic
            embedded={embedded}
            t={t}
            tripType={tripType}
            setTripType={setTripType}
            departure={departure}
            setDeparture={setDeparture}
            arrival={arrival}
            setArrival={setArrival}
            selectedHotel={selectedHotel}
            setSelectedHotel={setSelectedHotel}
            departureDate={departureDate}
            setDepartureDate={setDepartureDate}
            returnDate={returnDate}
            setReturnDate={setReturnDate}
            price={price}
            hotelOptions={hotelOptions}
            departureAddress={departureAddress}
            setDepartureAddress={setDepartureAddress}
            arrivalAddress={arrivalAddress}
            setArrivalAddress={setArrivalAddress}
            passengers={passengers}
            setPassengers={setPassengers}
            // Ouvre la modal et passe à 1.2
            nextStep={() => {
              setStep(2);
              setIsModalOpen(true);
            }}
          />
        )}
      </div>

      {/* Étapes suivantes dans une pop-up */}
      {isModalOpen && (
        <Modal size="md" onClose={() => { setIsModalOpen(false); setStep(1); }}>
          {step === 2 && (
            <Step1b_TripOptions
              embedded
              t={t}
              setPassengers={setPassengers}
              childSeats={childSeats}
              setChildSeats={setChildSeats}
              luggage={luggage}
              setLuggage={setLuggage}
              selectedVehicle={selectedVehicle}
              setSelectedVehicle={setSelectedVehicle}
              price={price}
              filteredVehicles={filteredVehicles}
              vehicleImages={vehicleImages}
              // Retour ferme la modal et revient à l'étape 1 (page)
              prevStep={() => { setStep(1); setIsModalOpen(false); }}
              nextStep={() => setStep(3)}
            />
          )}

          {step === 3 && (
            <Step2_CustomerInfo
              embedded
              t={t}
              fullName={fullName}
              setFullName={setFullName}
              email={email}
              setEmail={setEmail}
              phone={phone}
              setPhone={setPhone}
              flightNumber={flightNumber}
              setFlightNumber={setFlightNumber}
              comment={comment}
              setComment={setComment}
              captchaToken={captchaToken}
              setCaptchaToken={setCaptchaToken}
              prevStep={() => setStep(2)}
              nextStep={() => setStep(4)}
            />
          )}

          {step === 4 && (
            <Step3_Recap
              embedded
              t={t}
              tripType={tripType}
              departure={departure}
              arrival={arrival}
              selectedHotel={selectedHotel}
              departureDate={departureDate}
              returnDate={returnDate}
              passengers={passengers}
              childSeats={childSeats}
              luggage={luggage}
              selectedVehicle={selectedVehicle}
              price={price}
              fullName={fullName}
              email={email}
              phone={phone}
              flightNumber={flightNumber}
              comment={comment}
              prevStep={() => setStep(3)}
              sending={sending}
              setSending={setSending}
              mailStatus={mailStatus}
              setMailStatus={setMailStatus}
              handleConfirm={handleConfirm}
            />
          )}
        </Modal>
      )}
    </>
  );
};

/* ---------- Modal (focus fiable & taille contrôlée) ---------- */
function Modal({ children, onClose, size = "md" }) {
  const sizes = {
    sm: "max-w-[640px]",
    md: "max-w-[780px] md:max-w-[820px]",
    lg: "max-w-[960px]",
  };

  return createPortal(
    <div className="fixed inset-0 z-[100] pointer-events-none">
      {/* Backdrop cliquable */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm pointer-events-auto"
        onClick={onClose}
      />
      {/* Contenu interactif */}
      <div
        className="absolute inset-0 grid place-items-center p-4 pointer-events-none"
        role="dialog"
        aria-modal="true"
      >
        <div
          className={`relative w-auto ${sizes[size]} pointer-events-auto`}
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={onClose}
            aria-label="Fermer"
            className="absolute -top-10 right-0 rounded-full bg-white/20 hover:bg-white/30 text-white px-3 py-1"
          >
            ✕
          </button>

          <div className="bg-white text-slate-900 antialiased rounded-3xl shadow-2xl p-4 sm:p-6 md:p-8 max-h-[86vh] overflow-auto font-sans">
            {children}
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}

export default BookingFormApp;
